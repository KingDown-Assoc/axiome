// Content aggregation. Adding a field or a level = create a file in lessons/, then import it here.
import numbers from "./lessons/numbers.js";
import numbersPrimary from "./lessons/numbers-primary.js";
import algebra from "./lessons/algebra.js";
import geometry from "./lessons/geometry.js";
import geometryPrimary from "./lessons/geometry-primary.js";
import analysis from "./lessons/analysis.js";
import applied from "./lessons/applied.js";
import appliedPrimary from "./lessons/applied-primary.js";
import discrete from "./lessons/discrete.js";
import discretePrimary from "./lessons/discrete-primary.js";
import logic from "./lessons/logic.js";

export const LESSONS = [
  ...numbers, ...numbersPrimary,
  ...algebra,
  ...geometry, ...geometryPrimary,
  ...analysis,
  ...applied, ...appliedPrimary,
  ...discrete, ...discretePrimary,
  ...logic,
];
