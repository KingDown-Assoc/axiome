# Lycée — voie générale & technologique (2de · 1re · Tle)

Programmes actuellement en vigueur (BO de 2019, maths intégrées à l'enseignement scientifique : BO 2022). Une réforme est en cours (nouveaux programmes 2de/1re à la rentrée 2026-2027).

À déposer ici (tous les PDF sur la page éduscol voie GT) :
- Seconde GT · Spécialité 1re · Spécialité Tle · Maths complémentaires (Tle) · Maths expertes (Tle) · 1re « maths dans l'enseignement scientifique »
- Source : https://eduscol.education.gouv.fr/5817/programmes-et-ressources-en-mathematiques-voie-gt
