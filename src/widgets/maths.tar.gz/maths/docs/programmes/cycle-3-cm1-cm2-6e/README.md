# Cycle 3 — CM1 · CM2 · 6e

Nouveau programme de mathématiques — BO n° 16 du 17 avril 2025. Application : **CM1 et 6e à la rentrée 2025**, **CM2 à la rentrée 2026** (l'ancien programme reste en vigueur pour le CM2 en 2025-2026).

À déposer ici :
- `programme-maths-cycle3-2025.pdf` — arrêté : https://www.education.gouv.fr/bo/2025/Hebdo16/MENE2504620A
- ressources d'accompagnement (fractions, calcul mental, résolution de problèmes) — depuis https://eduscol.education.fr/251/mathematiques-cycle-3
