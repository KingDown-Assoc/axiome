# Cycle 1 — Maternelle (PS · MS · GS)

Programme « Acquérir les premiers outils mathématiques » — BO n° 41 du 31 octobre 2024, en application à la **rentrée 2025**. Objectifs déclinés par âge (avant 4 ans / à partir de 4 ans / à partir de 5 ans).

Fichiers présents :
- `programme-maths-cycle1-2024.pdf` — **le texte qui fait foi** (annexe 2 de l'arrêté, 15 p).
- `livret-avant-4-ans.pdf` (33 p), `livret-a-partir-de-4-ans.pdf` (38 p), `livret-a-partir-de-5-ans.pdf` (37 p) — livrets d'accompagnement éduscol : séquences et activités types par âge.
- `annexe-sequence-2-bande-numerique-jusqua-10.docx` — annexe détaillée d'une séquence « construire la bande numérique jusqu'à 10 ».
- `guide-construction-du-nombre-maternelle.pdf` (130 p) — guide fondamental éduscol (didactique du nombre).
- `projet-programme-csp-cycle1.pdf` — projet CSP (version consultative antérieure au BO) ; conservé pour archive, **ne fait pas foi**.

Sources : education.gouv.fr (BO n° 41 du 31/10/2024) et eduscol.education.fr — Licence Ouverte / Etalab, attribution : ministère de l'Éducation nationale.
