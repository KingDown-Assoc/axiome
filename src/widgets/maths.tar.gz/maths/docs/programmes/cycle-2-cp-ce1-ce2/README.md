# Cycle 2 — CP · CE1 · CE2

Programme de mathématiques du cycle 2 — annexe 4 du BO n° 41 du 31 octobre 2024 (en vigueur : CP-CE1 rentrée 2025, CE2 rentrée 2026). Quatre domaines : Nombres, calcul et résolution de problèmes (au moins deux tiers du temps) ; Grandeurs et mesures ; Espace et géométrie ; Organisation et gestion de données.

Fichiers présents :
- `programme-maths-cycle2-2024.pdf` — **le texte qui fait foi** (annexe 4 de l'arrêté).
- `livret-cp.pdf`, `livret-ce1.pdf`, `livret-ce2.pdf` — livrets d'accompagnement éduscol (séquences types par année).

Sources : education.gouv.fr (BO n° 41 du 31/10/2024) et eduscol.education.fr — Licence Ouverte / Etalab, attribution : ministère de l'Éducation nationale.
