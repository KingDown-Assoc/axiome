# Post-bac (CPGE · université / master)

- **CPGE** : programmes nationaux publiés par le ministère de l'Enseignement supérieur (MPSI, PCSI, MP2I, etc.). À récupérer le moment venu.
- **Université / Grande école (licence, master)** : il n'existe **pas** de programme national. Chaque établissement fixe sa propre maquette ; on s'appuiera sur des syllabus de référence (au choix) plutôt que sur un texte officiel unique.
