# Cycle 4 — 5e · 4e · 3e

Nouveau programme de mathématiques — BO n° 10 du 5 mars 2026. Application progressive : **5e à la rentrée 2026**, **4e en 2027**, **3e en 2028**. (Jusque-là, l'ancien programme reste en vigueur.)

À déposer ici :
- `programme-maths-cycle4-2026.pdf` — depuis le portail collège : https://www.education.gouv.fr/les-programmes-du-college-470408
- `guide-resolution-problemes-college.pdf` — https://eduscol.education.fr/document/13132/download
