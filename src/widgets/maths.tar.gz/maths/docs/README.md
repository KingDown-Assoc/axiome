# `docs/` — Programmes officiels & méthodes de référence

Ce dossier rassemble les **textes officiels** sur lesquels Axiome adosse ses cursus et ses exercices, de la maternelle au post-bac, ainsi que les **méthodes pédagogiques** de référence (méthode de Singapour, guides fondamentaux éduscol).

Objectif : rendre la plateforme **traçable** — chaque niveau de contenu peut être rattaché à un programme officiel — et **légitime**, en s'appuyant sur les programmes de l'Éducation nationale (France) et sur des références internationales reconnues.

> Les PDF eux-mêmes ne sont pas forcément versionnés ici (poids) : libre à toi de les committer ou de ne garder que les liens. Ce dossier est **hors build** — Vite ne compile que `src/` + `index.html`, et le Dockerfile ne copie que `dist/`, donc `docs/` n'alourdit pas l'image.

## Arborescence

```
docs/
├── README.md                       ← ce fichier (index + liens)
├── programmes/
│   ├── cycle-1-maternelle/          PS · MS · GS
│   ├── cycle-2-cp-ce1-ce2/          CP · CE1 · CE2
│   ├── cycle-3-cm1-cm2-6e/          CM1 · CM2 · 6e
│   ├── cycle-4-5e-4e-3e/            5e · 4e · 3e
│   ├── lycee-gt/                    2de · 1re · Tle (voie générale & techno)
│   └── post-bac/                    CPGE · université / master
└── methodes/
    ├── singapour/                   syllabus MOE + cadrage éduscol
    └── guides-eduscol/              guides fondamentaux
```

Chaque sous-dossier contient un `README.md` qui précise les fichiers à y déposer et leur source.

## Programmes officiels (Éducation nationale)

La refonte des programmes de mathématiques se déploie par vagues. État au moment de la rédaction :

| Cycle | Niveaux | Texte de référence | Entrée en vigueur | Source officielle |
|---|---|---|---|---|
| **1 — Maternelle** | PS · MS · GS | Programme « Premiers outils mathématiques » — BO n° 41 du 31/10/2024 | Rentrée 2025 | [PDF programme](https://www.education.gouv.fr/media/194202/download) · [éduscol cycle 1](https://eduscol.education.fr/2819/acquerir-les-premiers-outils-mathematiques-cycle-1) |
| **2 — CP/CE1/CE2** | CP · CE1 · CE2 | Programme — BO n° 41 du 31/10/2024 | Rentrée 2025 | [Arrêté BO](https://www.education.gouv.fr/bo/2024/Hebdo41/MENE2415135A) |
| **3 — CM/6e** | CM1 · CM2 · 6e | Programme — BO n° 16 du 17/04/2025 | CM1 + 6e en 2025 ; CM2 en 2026 | [Arrêté BO](https://www.education.gouv.fr/bo/2025/Hebdo16/MENE2504620A) · [éduscol cycle 3](https://eduscol.education.fr/251/mathematiques-cycle-3) |
| **4 — Collège** | 5e · 4e · 3e | Programme — BO n° 10 du 05/03/2026 | 5e en 2026 ; 4e en 2027 ; 3e en 2028 | [Portail collège](https://www.education.gouv.fr/les-programmes-du-college-470408) |
| **Lycée GT** | 2de · 1re · Tle | Programmes BO 2019 (réforme en cours : 2de/1re à la rentrée 2026) | En vigueur | [éduscol voie GT](https://eduscol.education.gouv.fr/5817/programmes-et-ressources-en-mathematiques-voie-gt) |
| **Post-bac** | CPGE / master | CPGE : programmes nationaux MESR — Université/master : maquette propre à chaque établissement (pas de programme national) | — | (à compléter) |

### Repères de structure
- **Maternelle (cycle 1)** : 5 thématiques — nombres (cardinal), nombres (ordinal), résoudre des problèmes, solides & formes planes, grandeurs (longueur & masse), motifs organisés. Nombres jusqu'à 10. Objectifs déclinés par âge.
- **CP → 3e (cycles 2-4)** : 4 domaines — Nombres/calcul/résolution de problèmes ; Grandeurs et mesures ; Espace et géométrie ; Organisation et gestion de données.

## Méthodes & ressources pédagogiques

| Ressource | Quoi | Lien |
|---|---|---|
| **Méthode de Singapour** | Syllabus officiel MOE (Primaire P1-P6, éd. 2021, maj oct. 2025) — CPA, modélisation en barres, résolution de problèmes (Pólya) | [PDF MOE](https://www.moe.gov.sg/api/media/92bff26d-b2b4-4535-b868-b8415c744b91/2021-Primary-Mathematics-Syllabus-P1-to-P6-Updated-October-2025.pdf) |
| **Singapour — cadrage FR** | Série éduscol « Perspectives sur la méthode de Singapour » | [éduscol maths](https://eduscol.education.fr/maths/) |
| **Guides fondamentaux éduscol** | Collection officielle (recherche + comparaison internationale) | [Portail](https://eduscol.education.fr/3107/guides-fondamentaux-pour-l-enseignement) |
| ↳ Guide CP | Nombres, calcul et résolution de problèmes au CP (154 p) | [PDF](https://eduscol.education.fr/document/3738/download) |
| ↳ Guide maternelle | Pour enseigner la construction du nombre à l'école maternelle | [éduscol cycle 1](https://eduscol.education.fr/83/j-enseigne-au-cycle-1) |
| ↳ Guide collège | La résolution de problèmes mathématiques au collège | [PDF](https://eduscol.education.fr/document/13132/download) |

## Licence & attribution

- **Documents de l'Éducation nationale (BO, éduscol)** : diffusés sous **Licence Ouverte / Etalab**, réutilisables y compris en redistribution, à condition de **mentionner la source** (ministère + référence du BO). Conserver les URL d'origine ci-dessus suffit pour l'attribution.
- **Syllabus MOE Singapour** : © Ministry of Education, Singapore. À usage de **référence** pour la conception des cursus ; conserver la mention de source et le lien officiel.

## Cartographie programme → Axiome (à tenir à jour)

- Niveau **Éveil** d'Axiome ⇄ cycle 1 (maternelle), avec un pont assumé vers le cycle 2.
- Niveau **Primaire (CP)** ⇄ cycle 2.
- (à compléter au fur et à mesure de l'ouverture des niveaux supérieurs)
