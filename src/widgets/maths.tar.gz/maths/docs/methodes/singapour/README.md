# Méthode de Singapour

Source primaire : le syllabus officiel du ministère de l'Éducation de Singapour (MOE).

Fichier présent :
- `moe-primary-maths-syllabus-2021-maj-oct2025.pdf` — **Mathematics Syllabus Primary One to Six**, édition 2021, mise à jour octobre 2025. En 2025 il s'applique de P1 à P5 ; il couvre P6 à partir de 2026 (P6 2025 restant sur l'édition 2013). Contenu : 3 domaines (Number & Algebra, Measurement & Geometry, Statistics), cadre « Mathematical Problem Solving » (concepts/skills/processes/metacognition/attitudes), 6 familles de « big ideas » (équivalence, diagrammes, invariance, mesures, notations, proportionnalité), pédagogie (phases Readiness/Engagement/Mastery), et le détail des objectifs **niveau par niveau** P1→P6 + filière Foundation (P5-P6).

Licence : © Curriculum Planning and Development Division, MOE Singapore — reproduction intégrale autorisée pour un usage personnel et non commercial (mention en page de garde). Conservé ici comme référence pédagogique.

Liens (les URL MOE changent ; celles-ci fonctionnaient à la date d'archivage) :
- PDF : https://www.moe.gov.sg/api/media/92bff26d-b2b4-4535-b868-b8415c744b91/2021-Primary-Mathematics-Syllabus-P1-to-P6-Updated-October-2025.pdf
- Page officielle : https://www.moe.gov.sg (rubrique Primary > Curriculum > Syllabuses)
- Cadrage officiel français : série éduscol « Perspectives sur la méthode de Singapour » — https://eduscol.education.fr/maths/
