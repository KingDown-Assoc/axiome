# Guides fondamentaux éduscol

Collection officielle (depuis 2018), fondée sur la recherche et la comparaison internationale.

À déposer ici / liens :
- Portail : https://eduscol.education.fr/3107/guides-fondamentaux-pour-l-enseignement
- Pour enseigner les nombres, le calcul et la résolution de problèmes au CP — https://eduscol.education.fr/document/3738/download
- La résolution de problèmes mathématiques au collège — https://eduscol.education.fr/document/13132/download
